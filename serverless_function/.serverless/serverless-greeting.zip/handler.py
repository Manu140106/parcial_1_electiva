def hello(event, context):
    return {
        "statusCode": 200,
        "body": "Hello, Paula y Manuela!"
    }
 
